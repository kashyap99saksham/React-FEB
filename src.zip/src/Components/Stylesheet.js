import React from 'react'
import './myStyle.css'

const Stylesheet = () => {
  return (
    <div>
        <h1 className = 'myPrimary'> Stylesheet </h1>
    </div>
  )
}

export default Stylesheet


// class Abc 