import React from 'react'


const Inline = () => {
  return (
    <>
      <div className={ style.success }> Inline </div>
      <h1 className='error'>Error from inline component</h1>
    </>
    )
}

export default Inline